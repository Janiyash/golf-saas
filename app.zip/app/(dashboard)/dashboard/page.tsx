'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@supabase/supabase-js'
import NavBar from '@/components/Navbar'

// ─── Supabase Client ──────────────────────────────────────────────────────────
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

// ─── Types matching your exact SQL schema ────────────────────────────────────
interface Score {
  id: string        // uuid
  value: number     // maps to scores.score
  date: string      // maps to scores.played_at
}

interface DrawEntry {
  id: string
  month: string
  numbers: number[]
  status: 'pending' | 'matched3' | 'matched4' | 'matched5' | 'no-match'
  prize?: string
  drawStatus: string
}

interface NavItem {
  id: string
  icon: string
  label: string
}

interface UserProfile {
  id: string
  name: string
  plan: string
  charity_name: string
  charity_pct: number
  total_donated: number
  member_since: string
  next_renewal: string
  payment_method: string
  subscription_status: string
}

interface WinningsData {
  total: number
  prizes_won: number
  draws_entered: number
  win_rate: number
  prize_history: { month: string; match: string; amount: string; status: 'paid' | 'pending-pay' }[]
}

interface ActivityItem {
  icon: string
  cls: string
  text: string
  time: string
}

const NAV_ITEMS: NavItem[] = [
  { id: 'overview', icon: '◈', label: 'Overview' },
  { id: 'scores', icon: '⛳', label: 'My Scores' },
  { id: 'draws', icon: '🎲', label: 'Prize Draws' },
  { id: 'charity', icon: '💚', label: 'My Charity' },
  { id: 'subscription', icon: '◉', label: 'Subscription' },
  { id: 'winnings', icon: '🏆', label: 'Winnings' },
]

// Helper: map winners.match_type (int) → DrawEntry status string
const matchTypeToStatus = (matchType: number): DrawEntry['status'] => {
  if (matchType >= 5) return 'matched5'
  if (matchType === 4) return 'matched4'
  if (matchType === 3) return 'matched3'
  return 'no-match'
}

const matchTypeToLabel = (matchType: number): string => {
  if (matchType >= 5) return 'Jackpot Winner'
  if (matchType === 4) return '4 Number Match'
  if (matchType === 3) return '3 Number Match'
  return 'No Match'
}

// ─── Component ────────────────────────────────────────────────────────────────
export default function Dashboard() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<string>('overview')
  const [isLoaded, setIsLoaded] = useState<boolean>(false)
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(true)
  const [scores, setScores] = useState<Score[]>([])
  const [newScore, setNewScore] = useState<string>('')
  const [newDate, setNewDate] = useState<string>('')
  const [scoreMsg, setScoreMsg] = useState<string>('')
  const [loading, setLoading] = useState<boolean>(true)

  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [charityPct, setCharityPct] = useState<number>(15)
  const [draws, setDraws] = useState<DrawEntry[]>([])
  const [nextDraw, setNextDraw] = useState<{ month: string; date: string } | null>(null)
  const [winningsData, setWinningsData] = useState<WinningsData>({
    total: 0, prizes_won: 0, draws_entered: 0, win_rate: 0, prize_history: [],
  })
  const [activityFeed, setActivityFeed] = useState<ActivityItem[]>([])
  const [countdown, setCountdown] = useState<{ days: string; hours: string; mins: string }>({ days: '00', hours: '00', mins: '00' })
  const [appUserId, setAppUserId] = useState<string | null>(null)

  const cursorRef = useRef<HTMLDivElement>(null)
  const cursorDotRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setIsLoaded(true)
    const handleMouse = (e: MouseEvent) => {
      if (cursorRef.current) cursorRef.current.style.transform = `translate(${e.clientX - 20}px, ${e.clientY - 20}px)`
      if (cursorDotRef.current) cursorDotRef.current.style.transform = `translate(${e.clientX - 4}px, ${e.clientY - 4}px)`
    }
    window.addEventListener('mousemove', handleMouse)
    return () => window.removeEventListener('mousemove', handleMouse)
  }, [])

  useEffect(() => { fetchAllData() }, [])

  useEffect(() => {
    if (!nextDraw?.date) return
    const tick = () => {
      const diff = new Date(nextDraw.date).getTime() - Date.now()
      if (diff <= 0) { setCountdown({ days: '00', hours: '00', mins: '00' }); return }
      setCountdown({
        days: String(Math.floor(diff / 86400000)).padStart(2, '0'),
        hours: String(Math.floor((diff % 86400000) / 3600000)).padStart(2, '0'),
        mins: String(Math.floor((diff % 3600000) / 60000)).padStart(2, '0'),
      })
    }
    tick()
    const interval = setInterval(tick, 30000)
    return () => clearInterval(interval)
  }, [nextDraw?.date])

  // ─── Fetch All Data — uses your actual table/column names ─────────────────
  const fetchAllData = async () => {
    setLoading(true)
    try {
      // 1. Auth user
      const { data: { user: authUser } } = await supabase.auth.getUser()
      if (!authUser) { router.push('/login'); return }

      // 2. Look up your `users` table by email (your users table has its own uuid,
      //    separate from Supabase auth uid)
      const { data: appUser, error: userErr } = await supabase
        .from('users')
        .select('id, name, email, subscription_status, charity_id, charity_percentage')
        .eq('email', authUser.email)
        .single()

      if (userErr || !appUser) {
        console.error('User not found in users table:', userErr)
        setLoading(false)
        return
      }

      const userId: string = appUser.id
      setAppUserId(userId)

      // 3. Fetch charity — charities table
      let charityName = "St. Jude Children's Research Hospital"
      let charityTotalDonated = 0
      if (appUser.charity_id) {
        const { data: charity } = await supabase
          .from('charities')
          .select('name, total_donations')
          .eq('id', appUser.charity_id)
          .single()
        if (charity) {
          charityName = charity.name
          charityTotalDonated = parseFloat(charity.total_donations) || 0
        }
      }

      // 4. Fetch subscription — subscriptions table
      const { data: sub } = await supabase
        .from('subscriptions')
        .select('plan, status, start_date, end_date')
        .eq('user_id', userId)
        .eq('status', 'active')
        .order('start_date', { ascending: false })
        .limit(1)
        .maybeSingle()

      const planLabel = sub?.plan === 'yearly' ? 'Pro Yearly' : 'Pro Monthly'

      setUserProfile({
        id: userId,
        name: appUser.name || authUser.email?.split('@')[0] || 'Member',
        plan: planLabel,
        charity_name: charityName,
        charity_pct: appUser.charity_percentage || 10,
        total_donated: charityTotalDonated,
        member_since: sub?.start_date || '',
        next_renewal: sub?.end_date || '',
        payment_method: 'Card on file',
        subscription_status: appUser.subscription_status || 'active',
      })
      setCharityPct(appUser.charity_percentage || 10)

      // 5. Fetch scores — columns are `score` and `played_at` (not `value`/`date`)
      const { data: scoresData } = await supabase
        .from('scores')
        .select('id, score, played_at')
        .eq('user_id', userId)
        .order('played_at', { ascending: false })
        .limit(5)

      if (scoresData) {
        setScores(scoresData.map((s: any) => ({
          id: s.id,
          value: s.score,       // DB column: score
          date: s.played_at,    // DB column: played_at
        })))
      }

      // 6. Fetch all draws — no user_id on draws table (it's global)
      const { data: allDraws } = await supabase
        .from('draws')
        .select('id, month, numbers, type, status')
        .order('month', { ascending: false })

      // 7. Fetch this user's winners — winners table
      const { data: myWinners } = await supabase
        .from('winners')
        .select('id, draw_id, match_type, prize_amount, status')
        .eq('user_id', userId)

      // Build draw_id → winner lookup
      const winnerByDraw: Record<string, any> = {}
      if (myWinners) myWinners.forEach((w: any) => { winnerByDraw[w.draw_id] = w })

      // 8. Map draws with winner data
      if (allDraws) {
        const mappedDraws: DrawEntry[] = allDraws.map((d: any) => {
          const winner = winnerByDraw[d.id]
          let status: DrawEntry['status'] = 'pending'
          let prize: string | undefined

          if (d.status === 'published') {
            if (winner) {
              status = matchTypeToStatus(winner.match_type)
              prize = winner.prize_amount ? `£${parseFloat(winner.prize_amount).toFixed(2)}` : undefined
            } else {
              status = 'no-match'
            }
          }
          // draft stays 'pending'

          return {
            id: d.id,
            month: d.month,
            numbers: Array.isArray(d.numbers) ? d.numbers : [],
            status,
            prize,
            drawStatus: d.status,
          }
        })
        setDraws(mappedDraws)

        // Next draw = latest draft
        const draftDraw = allDraws.find((d: any) => d.status === 'draft')
        if (draftDraw) {
          // Parse "April 2026" → end-of-month date for countdown
          const parts = draftDraw.month.split(' ')
          let endOfMonth = ''
          if (parts.length === 2) {
            const d = new Date(`${parts[0]} 1, ${parts[1]}`)
            d.setMonth(d.getMonth() + 1)
            d.setDate(0)
            endOfMonth = d.toISOString()
          }
          setNextDraw({ month: draftDraw.month, date: endOfMonth })
        }
      }

      // 9. Winnings from winners table — join draw month from allDraws
      if (myWinners) {
        const total = myWinners.reduce((s: number, w: any) => s + (parseFloat(w.prize_amount) || 0), 0)
        const publishedCount = allDraws ? allDraws.filter((d: any) => d.status === 'published').length : 0
        setWinningsData({
          total,
          prizes_won: myWinners.length,
          draws_entered: publishedCount,
          win_rate: publishedCount > 0 ? Math.round((myWinners.length / publishedCount) * 100) : 0,
          prize_history: myWinners.map((w: any) => {
            const draw = allDraws?.find((d: any) => d.id === w.draw_id)
            return {
              month: draw?.month || '—',
              match: matchTypeToLabel(w.match_type),
              amount: `£${parseFloat(w.prize_amount || 0).toFixed(2)}`,
              status: w.status === 'paid' ? 'paid' as const : 'pending-pay' as const,
            }
          }),
        })
      }

      // 10. Activity feed — derived from real data (no activity_feed table in your schema)
      const feed: ActivityItem[] = []
      if (scoresData && scoresData.length > 0) {
        const latest = scoresData[0]
        feed.push({
          icon: '⛳', cls: 'green',
          text: `New score entered — ${latest.score} pts Stableford`,
          time: new Date(latest.played_at).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }),
        })
      }
      if (myWinners && myWinners.length > 0) {
        const latestWin = myWinners[0]
        const winDraw = allDraws?.find((d: any) => d.id === latestWin.draw_id)
        feed.push({
          icon: '🏆', cls: 'gold',
          text: `${winDraw?.month || 'Draw'} — ${matchTypeToLabel(latestWin.match_type)}${latestWin.prize_amount ? ` · £${parseFloat(latestWin.prize_amount).toFixed(2)} won` : ''}`,
          time: '',
        })
      }
      if (sub) {
        feed.push({
          icon: '◉', cls: 'blue',
          text: `Subscription active — ${planLabel}`,
          time: sub.start_date ? new Date(sub.start_date).toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '',
        })
      }
      if (appUser.charity_id) {
        feed.push({
          icon: '💚', cls: 'green',
          text: `Supporting ${charityName} — ${appUser.charity_percentage}% of subscription`,
          time: '',
        })
      }
      setActivityFeed(feed)

    } catch (err) {
      console.error('Error fetching dashboard data:', err)
    } finally {
      setLoading(false)
    }
  }

  // ─── Computed Stats ───────────────────────────────────────────────────────
  const avg = scores.length > 0 ? (scores.reduce((s, x) => s + x.value, 0) / scores.length).toFixed(1) : '—'
  const best = scores.length > 0 ? Math.max(...scores.map(s => s.value)) : 0
  const trend = scores.length >= 2 ? scores[0].value - scores[scores.length - 1].value : 0

  // ─── Add Score — uses DB column names: `score`, `played_at` ──────────────
  const handleAddScore = async () => {
    const val = parseInt(newScore)
    if (!val || val < 1 || val > 45) { setScoreMsg('Score must be between 1 and 45'); return }
    if (!newDate) { setScoreMsg('Please select a date'); return }
    if (!appUserId) { setScoreMsg('User not found. Please refresh.'); return }
    try {
      const { data, error } = await supabase
        .from('scores')
        .insert([{ user_id: appUserId, score: val, played_at: newDate }])
        .select('id, score, played_at')
        .single()
      if (error) { setScoreMsg('Error saving score. Please try again.'); return }
      setScores(prev => [{ id: data.id, value: data.score, date: data.played_at }, ...prev].slice(0, 5))
      setNewScore(''); setNewDate('')
      setScoreMsg('✓ Score added successfully!')
      setTimeout(() => setScoreMsg(''), 3000)
    } catch { setScoreMsg('Error saving score. Please try again.') }
  }

  // ─── Delete Score ─────────────────────────────────────────────────────────
  const handleDeleteScore = async (id: string) => {
    try {
      await supabase.from('scores').delete().eq('id', id)
      setScores(prev => prev.filter(s => s.id !== id))
    } catch { console.error('Error deleting score') }
  }

  // ─── Update Charity % — saves to users.charity_percentage ────────────────
  const handleCharityPctChange = async (val: number) => {
    setCharityPct(val)
    if (!appUserId) return
    try {
      await supabase.from('users').update({ charity_percentage: val }).eq('id', appUserId)
    } catch { console.error('Error updating charity percentage') }
  }

  const getStatusBadge = (status: DrawEntry['status']) => {
    const map: Record<DrawEntry['status'], { label: string; color: string }> = {
      pending:    { label: 'Pending',   color: 'rgba(201,168,76,0.15)' },
      matched3:   { label: '3 Match',   color: 'rgba(61,186,110,0.15)' },
      matched4:   { label: '4 Match',   color: 'rgba(61,186,110,0.25)' },
      matched5:   { label: 'JACKPOT!',  color: 'rgba(201,168,76,0.3)'  },
      'no-match': { label: 'No Match',  color: 'rgba(122,138,121,0.15)'},
    }
    return map[status]
  }

  const formatDate = (d: string) => d ? new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) : '—'
  const formatMonthYear = (d: string) => d ? new Date(d).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }) : '—'
  const monthsSince = (d: string) => {
    if (!d) return 0
    const s = new Date(d); const n = new Date()
    return (n.getFullYear() - s.getFullYear()) * 12 + (n.getMonth() - s.getMonth())
  }

  const perMonthCharity = (4.99 * charityPct / 100).toFixed(2)
  const totalDonated = userProfile?.total_donated || 0
  const monthsContributing = userProfile?.member_since ? monthsSince(userProfile.member_since) : 0

  return (
    <>
    <NavBar />
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=DM+Sans:wght@300;400;500&display=swap');
        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
          --gold: #C9A84C; --gold-light: #F0D080; --gold-dim: #8B6914;
          --green: #1A4A2E; --green-mid: #2D6A44; --green-bright: #3DBA6E;
          --cream: #FAF6EE; --dark: #080C07; --dark2: #0E1510; --dark3: #111A12;
          --text-muted: #7A8A79; --border: rgba(201,168,76,0.1);
          --sidebar-w: 260px;
        }
        html { cursor: none; }
        body { font-family: 'DM Sans', sans-serif; background: var(--dark); color: var(--cream); overflow-x: hidden; }
        .cursor-ring { position: fixed; width: 40px; height: 40px; border: 1.5px solid var(--gold); border-radius: 50%; pointer-events: none; z-index: 9999; transition: transform 0.12s ease; mix-blend-mode: difference; }
        .cursor-dot { position: fixed; width: 8px; height: 8px; background: var(--gold); border-radius: 50%; pointer-events: none; z-index: 10000; transition: transform 0.05s linear; }
        .noise { position: fixed; inset: 0; pointer-events: none; z-index: 0; opacity: 0.025; background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E"); }
        .dash-wrap { display: flex; min-height: 100vh; opacity: 0; transition: opacity 0.6s ease; }
        .dash-wrap.loaded { opacity: 1; }
        .sidebar { width: var(--sidebar-w); min-height: 100vh; background: var(--dark2); border-right: 1px solid var(--border); display: flex; flex-direction: column; position: fixed; left: 0; top: 0; bottom: 0; z-index: 50; transition: transform 0.4s cubic-bezier(0.4,0,0.2,1); }
        .sidebar.closed { transform: translateX(calc(-1 * var(--sidebar-w))); }
        .sidebar-user { padding: 20px 24px; border-bottom: 1px solid var(--border); }
        .user-avatar { width: 44px; height: 44px; border-radius: 50%; background: linear-gradient(135deg, var(--green-mid), var(--green)); border: 2px solid rgba(201,168,76,0.3); display: flex; align-items: center; justify-content: center; font-size: 18px; margin-bottom: 10px; }
        .user-name { font-size: 0.95rem; font-weight: 500; color: var(--cream); }
        .user-plan { font-size: 0.7rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--gold); margin-top: 2px; display: flex; align-items: center; gap: 6px; }
        .plan-dot { width: 5px; height: 5px; background: var(--green-bright); border-radius: 50%; animation: pulse 2s infinite; }
        @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.5;transform:scale(0.8)} }
        .sidebar-nav { flex: 1; padding: 16px 12px; display: flex; flex-direction: column; gap: 2px; }
        .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 14px; border-radius: 4px; cursor: none; transition: all 0.2s; border: 1px solid transparent; background: none; width: 100%; text-align: left; color: var(--text-muted); font-family: 'DM Sans', sans-serif; font-size: 0.88rem; font-weight: 400; }
        .nav-item:hover { background: rgba(201,168,76,0.05); color: var(--cream); border-color: rgba(201,168,76,0.08); }
        .nav-item.active { background: rgba(29,74,46,0.2); color: var(--cream); border-color: rgba(61,186,110,0.2); }
        .nav-item.active .nav-icon { color: var(--green-bright); }
        .nav-icon { font-size: 1rem; width: 20px; text-align: center; flex-shrink: 0; }
        .nav-active-bar { width: 3px; height: 20px; background: var(--green-bright); border-radius: 2px; margin-left: auto; opacity: 0; transition: opacity 0.2s; }
        .nav-item.active .nav-active-bar { opacity: 1; }
        .sidebar-footer { padding: 16px 12px; border-top: 1px solid var(--border); }
        .sidebar-logout { display: flex; align-items: center; gap: 12px; padding: 10px 14px; border-radius: 4px; cursor: none; transition: all 0.2s; background: none; border: none; color: var(--text-muted); font-family: 'DM Sans', sans-serif; font-size: 0.82rem; width: 100%; text-align: left; }
        .sidebar-logout:hover { color: #FCA5A5; background: rgba(239,68,68,0.05); }
        .main { flex: 1; margin-left: var(--sidebar-w); min-height: 100vh; display: flex; flex-direction: column; transition: margin-left 0.4s cubic-bezier(0.4,0,0.2,1); margin-top: 64px; }
        .main.sidebar-closed { margin-left: 0; }
        .topbar { height: 64px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 32px; background: rgba(8,12,7,0.6); backdrop-filter: blur(20px); position: sticky; top: 0; z-index: 40; }
        .topbar-left { display: flex; align-items: center; gap: 16px; }
        .toggle-btn { background: none; border: 1px solid var(--border); color: var(--text-muted); width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; cursor: none; border-radius: 4px; font-size: 1rem; transition: all 0.2s; }
        .toggle-btn:hover { border-color: rgba(201,168,76,0.3); color: var(--gold); }
        .topbar-title { font-family: 'Playfair Display', serif; font-size: 1.1rem; font-weight: 700; color: var(--cream); }
        .topbar-right { display: flex; align-items: center; gap: 16px; }
        .content { flex: 1; padding: 32px; }
        .loading-overlay { display: flex; align-items: center; justify-content: center; min-height: 300px; }
        .loading-spinner { width: 40px; height: 40px; border: 2px solid rgba(201,168,76,0.1); border-top-color: var(--gold); border-radius: 50%; animation: spin 0.8s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .card { background: var(--dark2); border: 1px solid var(--border); padding: 28px; position: relative; overflow: hidden; }
        .card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 1px; background: linear-gradient(90deg, transparent, rgba(201,168,76,0.3), transparent); }
        .card-label { font-size: 0.65rem; letter-spacing: 0.14em; text-transform: uppercase; color: var(--gold); margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
        .card-value { font-family: 'Playfair Display', serif; font-size: 2.4rem; font-weight: 900; color: var(--cream); line-height: 1; }
        .card-sub { font-size: 0.78rem; color: var(--text-muted); margin-top: 8px; }
        .card-icon { position: absolute; top: 24px; right: 24px; font-size: 2rem; opacity: 0.12; }
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1px; background: var(--border); margin-bottom: 24px; }
        .stat-card { background: var(--dark2); padding: 24px 28px; position: relative; overflow: hidden; transition: background 0.2s; }
        .stat-card:hover { background: var(--dark3); }
        .stat-card::after { content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 2px; background: linear-gradient(90deg, transparent, var(--gold), transparent); transform: scaleX(0); transition: transform 0.3s; }
        .stat-card:hover::after { transform: scaleX(1); }
        .stat-num { font-family: 'Playfair Display', serif; font-size: 2.2rem; font-weight: 900; color: var(--gold); line-height: 1; }
        .stat-num.green { color: var(--green-bright); }
        .stat-label { font-size: 0.7rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-muted); margin-top: 6px; }
        .stat-trend { font-size: 0.75rem; color: var(--green-bright); margin-top: 6px; }
        .stat-trend.down { color: #FCA5A5; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px; }
        .grid-3 { display: grid; grid-template-columns: 2fr 1fr; gap: 24px; margin-bottom: 24px; }
        .section-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
        .section-title { font-family: 'Playfair Display', serif; font-size: 1.15rem; font-weight: 700; color: var(--cream); }
        .section-eyebrow { font-size: 0.65rem; letter-spacing: 0.14em; text-transform: uppercase; color: var(--gold); margin-bottom: 6px; }
        .score-row { display: flex; align-items: center; gap: 16px; padding: 14px 0; border-bottom: 1px solid rgba(201,168,76,0.06); }
        .score-row:last-child { border-bottom: none; }
        .score-rank { font-family: 'Playfair Display', serif; font-size: 0.75rem; color: var(--text-muted); width: 24px; text-align: center; }
        .score-ball { width: 44px; height: 44px; border-radius: 2px; background: rgba(29,74,46,0.3); border: 1px solid rgba(61,186,110,0.15); display: flex; align-items: center; justify-content: center; font-family: 'Playfair Display', serif; font-size: 1.1rem; font-weight: 900; color: var(--cream); flex-shrink: 0; }
        .score-ball.best-score { background: rgba(61,186,110,0.15); border-color: rgba(61,186,110,0.4); color: var(--green-bright); }
        .score-info { flex: 1; }
        .score-course { font-size: 0.88rem; font-weight: 500; color: var(--cream); }
        .score-date { font-size: 0.72rem; color: var(--text-muted); margin-top: 2px; }
        .score-badge { font-size: 0.68rem; letter-spacing: 0.08em; text-transform: uppercase; padding: 3px 8px; border: 1px solid rgba(201,168,76,0.25); color: var(--gold); }
        .score-delete { background: none; border: none; color: var(--text-muted); cursor: none; font-size: 0.85rem; padding: 4px 8px; transition: color 0.2s; border-radius: 2px; }
        .score-delete:hover { color: #FCA5A5; background: rgba(239,68,68,0.08); }
        .score-bars { display: flex; align-items: flex-end; gap: 8px; height: 80px; margin-top: 16px; }
        .score-bar-item { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; }
        .score-bar-fill { width: 100%; background: linear-gradient(180deg, var(--green-bright), var(--green-mid)); border-radius: 2px 2px 0 0; transition: height 0.6s ease; }
        .score-bar-fill.highlight { background: linear-gradient(180deg, var(--gold-light), var(--gold)); }
        .score-bar-val { font-size: 0.65rem; color: var(--text-muted); }
        .add-score-form { border: 1px solid var(--border); background: var(--dark); padding: 24px; margin-top: 20px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr auto; gap: 12px; align-items: end; }
        .field-grp { display: flex; flex-direction: column; gap: 6px; }
        .field-lbl { font-size: 0.65rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-muted); }
        .field-inp { background: var(--dark2); border: 1px solid rgba(201,168,76,0.1); color: var(--cream); font-family: 'DM Sans', sans-serif; font-size: 0.9rem; padding: 10px 14px; outline: none; transition: border-color 0.2s; width: 100%; }
        .field-inp::placeholder { color: rgba(122,138,121,0.4); }
        .field-inp:focus { border-color: rgba(201,168,76,0.4); }
        .btn-add { background: linear-gradient(135deg, var(--gold), #E8C060); color: var(--dark); border: none; padding: 10px 20px; font-family: 'DM Sans', sans-serif; font-size: 0.82rem; font-weight: 500; letter-spacing: 0.08em; text-transform: uppercase; cursor: none; white-space: nowrap; transition: transform 0.2s, box-shadow 0.2s; }
        .btn-add:hover { transform: translateY(-1px); box-shadow: 0 8px 30px rgba(201,168,76,0.25); }
        .form-msg { font-size: 0.8rem; margin-top: 10px; }
        .form-msg.success { color: var(--green-bright); }
        .form-msg.error { color: #FCA5A5; }
        .draw-card { background: var(--dark2); border: 1px solid var(--border); padding: 24px; position: relative; overflow: hidden; margin-bottom: 12px; }
        .draw-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
        .draw-month { font-family: 'Playfair Display', serif; font-size: 1rem; font-weight: 700; }
        .draw-status { font-size: 0.68rem; letter-spacing: 0.08em; text-transform: uppercase; padding: 4px 10px; border: 1px solid rgba(201,168,76,0.25); }
        .draw-numbers { display: flex; gap: 8px; margin-bottom: 16px; }
        .draw-num { width: 44px; height: 44px; border-radius: 50%; background: rgba(29,74,46,0.2); border: 1px solid rgba(61,186,110,0.15); display: flex; align-items: center; justify-content: center; font-family: 'Playfair Display', serif; font-size: 1rem; font-weight: 900; }
        .draw-num.matched { background: rgba(61,186,110,0.2); border-color: rgba(61,186,110,0.5); color: var(--green-bright); }
        .draw-prize { font-size: 0.85rem; color: var(--gold); margin-top: 8px; }
        .jackpot-banner { background: linear-gradient(135deg, rgba(201,168,76,0.15), rgba(201,168,76,0.05)); border: 1px solid rgba(201,168,76,0.3); padding: 20px 24px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; }
        .jackpot-label { font-size: 0.65rem; letter-spacing: 0.14em; text-transform: uppercase; color: var(--gold); margin-bottom: 6px; }
        .jackpot-amount { font-family: 'Playfair Display', serif; font-size: 2.5rem; font-weight: 900; color: var(--gold); line-height: 1; }
        .jackpot-sub { font-size: 0.78rem; color: var(--text-muted); margin-top: 4px; }
        .jackpot-entries { text-align: right; }
        .jackpot-entry-num { font-family: 'Playfair Display', serif; font-size: 1.8rem; font-weight: 900; color: var(--cream); }
        .charity-card { background: var(--dark2); border: 1px solid var(--border); padding: 28px; margin-bottom: 20px; position: relative; overflow: hidden; }
        .charity-card::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 3px; background: linear-gradient(180deg, var(--green-bright), var(--green-mid)); }
        .charity-name { font-family: 'Playfair Display', serif; font-size: 1.3rem; font-weight: 700; color: var(--cream); margin-bottom: 6px; }
        .charity-desc { font-size: 0.85rem; color: var(--text-muted); line-height: 1.6; margin-bottom: 20px; }
        .charity-pct-row { display: flex; align-items: center; gap: 20px; }
        .pct-display { font-family: 'Playfair Display', serif; font-size: 2.5rem; font-weight: 900; color: var(--green-bright); line-height: 1; }
        .pct-label { font-size: 0.7rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-muted); margin-top: 4px; }
        .pct-slider { flex: 1; -webkit-appearance: none; appearance: none; height: 3px; background: rgba(255,255,255,0.08); outline: none; border-radius: 2px; cursor: none; }
        .pct-slider::-webkit-slider-thumb { -webkit-appearance: none; width: 16px; height: 16px; background: var(--green-bright); border-radius: 50%; cursor: none; border: 2px solid var(--dark2); }
        .charity-impact { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: 24px; }
        .impact-tile { background: rgba(8,12,7,0.5); border: 1px solid rgba(201,168,76,0.08); padding: 16px; }
        .impact-val { font-family: 'Playfair Display', serif; font-size: 1.3rem; font-weight: 700; color: var(--gold); }
        .impact-lbl { font-size: 0.7rem; color: var(--text-muted); margin-top: 4px; letter-spacing: 0.06em; text-transform: uppercase; }
        .charity-list { display: flex; flex-direction: column; gap: 10px; }
        .charity-option { display: flex; align-items: center; gap: 14px; padding: 14px 16px; border: 1px solid rgba(201,168,76,0.08); cursor: none; transition: all 0.2s; background: none; width: 100%; text-align: left; }
        .charity-option:hover { border-color: rgba(201,168,76,0.2); background: rgba(201,168,76,0.03); }
        .charity-option.selected { border-color: rgba(61,186,110,0.3); background: rgba(29,74,46,0.1); }
        .charity-opt-icon { width: 40px; height: 40px; background: rgba(29,74,46,0.3); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
        .charity-opt-name { font-size: 0.9rem; font-weight: 500; color: var(--cream); }
        .charity-opt-sub { font-size: 0.72rem; color: var(--text-muted); margin-top: 2px; }
        .charity-opt-check { margin-left: auto; width: 20px; height: 20px; border-radius: 50%; border: 1px solid rgba(61,186,110,0.3); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .charity-option.selected .charity-opt-check { background: var(--green-bright); border-color: var(--green-bright); color: var(--dark); font-size: 0.7rem; }
        .plan-card { background: var(--dark2); border: 1px solid var(--border); padding: 28px; margin-bottom: 20px; position: relative; }
        .plan-badge { display: inline-flex; align-items: center; gap: 8px; border: 1px solid rgba(201,168,76,0.3); padding: 4px 12px; font-size: 0.7rem; letter-spacing: 0.12em; text-transform: uppercase; color: var(--gold); margin-bottom: 20px; }
        .plan-name { font-family: 'Playfair Display', serif; font-size: 1.8rem; font-weight: 900; color: var(--cream); margin-bottom: 4px; }
        .plan-price { font-size: 0.9rem; color: var(--text-muted); margin-bottom: 20px; }
        .plan-price span { font-family: 'Playfair Display', serif; font-size: 1.6rem; font-weight: 900; color: var(--gold); }
        .plan-features { display: flex; flex-direction: column; gap: 10px; margin-bottom: 24px; }
        .plan-feat { display: flex; align-items: center; gap: 12px; font-size: 0.85rem; color: var(--cream); }
        .plan-feat-dot { width: 5px; height: 5px; background: var(--green-bright); border-radius: 50%; flex-shrink: 0; }
        .plan-actions { display: flex; gap: 12px; }
        .btn-outline { background: none; border: 1px solid rgba(201,168,76,0.3); color: var(--gold); padding: 10px 20px; font-family: 'DM Sans', sans-serif; font-size: 0.8rem; letter-spacing: 0.08em; text-transform: uppercase; cursor: none; transition: all 0.2s; }
        .btn-outline:hover { background: rgba(201,168,76,0.05); border-color: rgba(201,168,76,0.5); }
        .btn-danger { background: none; border: 1px solid rgba(239,68,68,0.3); color: #FCA5A5; padding: 10px 20px; font-family: 'DM Sans', sans-serif; font-size: 0.8rem; letter-spacing: 0.08em; text-transform: uppercase; cursor: none; transition: all 0.2s; }
        .btn-danger:hover { background: rgba(239,68,68,0.05); }
        .renewal-info { background: rgba(29,74,46,0.1); border: 1px solid rgba(61,186,110,0.15); padding: 16px 20px; display: flex; align-items: center; justify-content: space-between; }
        .renewal-label { font-size: 0.7rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-muted); margin-bottom: 4px; }
        .renewal-date { font-size: 0.95rem; font-weight: 500; color: var(--cream); }
        .winnings-total { background: linear-gradient(135deg, rgba(201,168,76,0.12), rgba(201,168,76,0.04)); border: 1px solid rgba(201,168,76,0.25); padding: 32px; margin-bottom: 24px; display: flex; align-items: center; gap: 32px; }
        .win-total-val { font-family: 'Playfair Display', serif; font-size: 3.5rem; font-weight: 900; color: var(--gold); line-height: 1; }
        .win-total-label { font-size: 0.7rem; letter-spacing: 0.14em; text-transform: uppercase; color: var(--text-muted); margin-bottom: 4px; }
        .win-divider { width: 1px; height: 60px; background: rgba(201,168,76,0.2); }
        .win-stat-val { font-family: 'Playfair Display', serif; font-size: 1.5rem; font-weight: 700; color: var(--cream); }
        .win-stat-lbl { font-size: 0.7rem; color: var(--text-muted); margin-top: 2px; text-transform: uppercase; letter-spacing: 0.08em; }
        .win-row { display: flex; align-items: center; justify-content: space-between; padding: 16px 0; border-bottom: 1px solid rgba(201,168,76,0.06); }
        .win-row:last-child { border-bottom: none; }
        .win-month { font-size: 0.88rem; color: var(--cream); font-weight: 500; }
        .win-match { font-size: 0.72rem; color: var(--text-muted); margin-top: 2px; }
        .win-amount { font-family: 'Playfair Display', serif; font-size: 1.1rem; font-weight: 700; color: var(--green-bright); }
        .win-status { font-size: 0.68rem; letter-spacing: 0.08em; text-transform: uppercase; padding: 3px 8px; border: 1px solid; }
        .win-status.paid { border-color: rgba(61,186,110,0.3); color: var(--green-bright); }
        .win-status.pending-pay { border-color: rgba(201,168,76,0.3); color: var(--gold); }
        .activity-feed { display: flex; flex-direction: column; }
        .activity-item { display: flex; align-items: flex-start; gap: 14px; padding: 14px 0; border-bottom: 1px solid rgba(201,168,76,0.06); }
        .activity-item:last-child { border-bottom: none; }
        .activity-icon { width: 32px; height: 32px; border-radius: 2px; display: flex; align-items: center; justify-content: center; font-size: 0.9rem; flex-shrink: 0; }
        .activity-icon.green { background: rgba(29,74,46,0.3); }
        .activity-icon.gold { background: rgba(201,168,76,0.1); }
        .activity-icon.blue { background: rgba(59,130,246,0.1); }
        .activity-text { font-size: 0.85rem; color: var(--cream); line-height: 1.4; }
        .activity-time { font-size: 0.7rem; color: var(--text-muted); margin-top: 2px; }
        .ring-wrap { position: relative; width: 80px; height: 80px; }
        .ring-svg { transform: rotate(-90deg); }
        .ring-track { fill: none; stroke: rgba(255,255,255,0.06); stroke-width: 5; }
        .ring-fill { fill: none; stroke-width: 5; stroke-linecap: round; transition: stroke-dashoffset 1s ease; }
        .ring-label { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .ring-val { font-family: 'Playfair Display', serif; font-size: 1rem; font-weight: 700; line-height: 1; }
        .ring-lbl-txt { font-size: 0.55rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.08em; margin-top: 2px; }
        .countdown-row { display: flex; gap: 12px; margin-top: 12px; }
        .countdown-block { flex: 1; background: rgba(8,12,7,0.6); border: 1px solid rgba(201,168,76,0.12); padding: 12px 8px; text-align: center; }
        .countdown-num { font-family: 'Playfair Display', serif; font-size: 1.4rem; font-weight: 900; color: var(--cream); line-height: 1; }
        .countdown-lbl { font-size: 0.6rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-muted); margin-top: 4px; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: var(--dark); }
        ::-webkit-scrollbar-thumb { background: rgba(201,168,76,0.2); border-radius: 2px; }
        @media (max-width: 1100px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } .grid-2 { grid-template-columns: 1fr; } .grid-3 { grid-template-columns: 1fr; } }
        @media (max-width: 768px) { :root { --sidebar-w: 260px; } .sidebar { transform: translateX(calc(-1 * var(--sidebar-w))); } .sidebar.open { transform: translateX(0); } .main { margin-left: 0 !important; } .content { padding: 20px 16px; } .form-row { grid-template-columns: 1fr 1fr; } .charity-impact { grid-template-columns: 1fr 1fr; } .winnings-total { flex-direction: column; align-items: flex-start; gap: 16px; } .win-divider { width: 60px; height: 1px; } .jackpot-banner { flex-direction: column; gap: 12px; } }
        @media (max-width: 480px) { .stats-grid { grid-template-columns: 1fr 1fr; } .form-row { grid-template-columns: 1fr; } .plan-actions { flex-direction: column; } .charity-impact { grid-template-columns: 1fr; } }
      `}</style>

      <div ref={cursorRef} className="cursor-ring" />
      <div ref={cursorDotRef} className="cursor-dot" />
      <div className="noise" />

      <div className={`dash-wrap ${isLoaded ? 'loaded' : ''}`}>

        {/* ── SIDEBAR ── */}
        <aside className={`sidebar ${sidebarOpen ? '' : 'closed'}`}>
          <div style={{ height: '80px', flexShrink: 0 }} />
          <div className="sidebar-user">
            <div className="user-avatar">🏌️</div>
            <div className="user-name">{userProfile?.name || '—'}</div>
            <div className="user-plan">
              <span className="plan-dot" />
              {userProfile?.plan || 'Pro Member'} · {userProfile?.subscription_status === 'active' ? 'Active' : 'Inactive'}
            </div>
          </div>
          <nav className="sidebar-nav">
            {NAV_ITEMS.map(item => (
              <button key={item.id} className={`nav-item ${activeTab === item.id ? 'active' : ''}`} onClick={() => setActiveTab(item.id)}>
                <span className="nav-icon">{item.icon}</span>
                {item.label}
                <span className="nav-active-bar" />
              </button>
            ))}
          </nav>
          <div className="sidebar-footer">
            <button className="sidebar-logout" onClick={() => router.push('/login')}>
              <span>↩</span> Sign Out
            </button>
          </div>
        </aside>

        {/* ── MAIN ── */}
        <main className={`main ${sidebarOpen ? '' : 'sidebar-closed'}`}>
          <div className="topbar">
            <div className="topbar-left">
              <button className="toggle-btn" onClick={() => setSidebarOpen(p => !p)}>☰</button>
              <span className="topbar-title">{NAV_ITEMS.find(n => n.id === activeTab)?.label ?? 'Dashboard'}</span>
            </div>

          </div>

          <div className="content">
            {loading ? (
              <div className="loading-overlay"><div className="loading-spinner" /></div>
            ) : (
              <>

              {/* ────────────────── OVERVIEW ────────────────── */}
              {activeTab === 'overview' && (
                <>
                  <div className="stats-grid">
                    <div className="stat-card">
                      <div className="stat-label">Average Score</div>
                      <div className="stat-num">{avg}</div>
                      <div className="stat-trend">pts Stableford</div>
                    </div>
                    <div className="stat-card">
                      <div className="stat-label">Best Score</div>
                      <div className="stat-num green">{best || '—'}</div>
                      <div className="stat-trend">↑ Personal best</div>
                    </div>
                    <div className="stat-card">
                      <div className="stat-label">Draws Entered</div>
                      <div className="stat-num">{winningsData.draws_entered}</div>
                      <div className="stat-trend">Published draws</div>
                    </div>
                    <div className="stat-card">
                      <div className="stat-label">Charity Pool</div>
                      <div className="stat-num green">£{totalDonated.toFixed(0)}</div>
                      <div className="stat-trend">↑ Total contributions</div>
                    </div>
                  </div>

                  <div className="grid-3">
                    <div className="card">
                      <div className="card-icon">⛳</div>
                      <div className="section-eyebrow">Performance</div>
                      <div className="section-head">
                        <div className="section-title">Your Last 5 Scores</div>
                        <button className="btn-outline" style={{ padding: '6px 14px', fontSize: '0.72rem' }} onClick={() => setActiveTab('scores')}>View All</button>
                      </div>
                      {scores.length > 0 ? (
                        <>
                          <div className="score-bars" style={{ marginBottom: 16 }}>
                            {scores.map(s => (
                              <div key={s.id} className="score-bar-item">
                                <div className={`score-bar-fill ${s.value === best ? 'highlight' : ''}`} style={{ height: `${(s.value / 45) * 100}%` }} />
                                <span className="score-bar-val">{s.value}</span>
                              </div>
                            ))}
                          </div>
                          {scores.slice(0, 3).map((s, i) => (
                            <div key={s.id} className="score-row">
                              <span className="score-rank">#{i + 1}</span>
                              <div className={`score-ball ${s.value === best ? 'best-score' : ''}`}>{s.value}</div>
                              <div className="score-info">
                                <div className="score-course">{new Date(s.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}</div>
                                <div className="score-date">{s.value} pts Stableford</div>
                              </div>
                              {s.value === best && <span className="score-badge">Best</span>}
                            </div>
                          ))}
                        </>
                      ) : (
                        <div style={{ textAlign: 'center', padding: '32px 0', color: 'var(--text-muted)', fontSize: '0.9rem' }}>No scores yet. Add your first score.</div>
                      )}
                    </div>

                    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
                      <div className="card" style={{ flex: 'none' }}>
                        <div className="section-eyebrow">Prize Draw</div>
                        <div className="section-title" style={{ marginBottom: 8 }}>Next Draw</div>
                        <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginBottom: 12 }}>{nextDraw?.month || 'Coming soon'}</div>
                        <div className="jackpot-banner" style={{ padding: '16px 20px', marginBottom: 0 }}>
                          <div>
                            <div className="jackpot-label">Jackpot Pool</div>
                            <div className="jackpot-amount" style={{ fontSize: '1.8rem' }}>£5,000</div>
                          </div>
                          <div style={{ textAlign: 'right' }}>
                            <div className="jackpot-label" style={{ textAlign: 'right' }}>Draws</div>
                            <div className="jackpot-entry-num" style={{ fontSize: '1.4rem' }}>{winningsData.draws_entered}</div>
                          </div>
                        </div>
                        <div className="countdown-row">
                          {[{ n: countdown.days, l: 'Days' }, { n: countdown.hours, l: 'Hours' }, { n: countdown.mins, l: 'Mins' }].map(({ n, l }) => (
                            <div key={l} className="countdown-block">
                              <div className="countdown-num">{n}</div>
                              <div className="countdown-lbl">{l}</div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="card" style={{ flex: 1 }}>
                        <div className="section-eyebrow">This Month's Impact</div>
                        <div className="section-title" style={{ marginBottom: 16 }}>{userProfile?.charity_name || "St. Jude's Hospital"}</div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                          <div className="ring-wrap">
                            <svg className="ring-svg" width="80" height="80" viewBox="0 0 80 80">
                              <circle className="ring-track" cx="40" cy="40" r="35" />
                              <circle className="ring-fill" cx="40" cy="40" r="35" stroke="var(--green-bright)"
                                strokeDasharray={`${2 * Math.PI * 35}`}
                                strokeDashoffset={`${2 * Math.PI * 35 * (1 - charityPct / 100)}`} />
                            </svg>
                            <div className="ring-label">
                              <span className="ring-val" style={{ color: 'var(--green-bright)' }}>{charityPct}%</span>
                              <span className="ring-lbl-txt">Given</span>
                            </div>
                          </div>
                          <div>
                            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Total donated</div>
                            <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.4rem', fontWeight: 900, color: 'var(--green-bright)', lineHeight: 1.2 }}>£{totalDonated.toFixed(2)}</div>
                            <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 4 }}>Charity pool total</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="card">
                    <div className="section-eyebrow">Timeline</div>
                    <div className="section-head"><div className="section-title">Recent Activity</div></div>
                    <div className="activity-feed">
                      {activityFeed.length > 0 ? activityFeed.map((a, i) => (
                        <div key={i} className="activity-item">
                          <div className={`activity-icon ${a.cls}`}>{a.icon}</div>
                          <div>
                            <div className="activity-text">{a.text}</div>
                            {a.time && <div className="activity-time">{a.time}</div>}
                          </div>
                        </div>
                      )) : (
                        <div style={{ textAlign: 'center', padding: '24px 0', color: 'var(--text-muted)', fontSize: '0.85rem' }}>No recent activity.</div>
                      )}
                    </div>
                  </div>
                </>
              )}

              {/* ────────────────── SCORES ────────────────── */}
              {activeTab === 'scores' && (
                <>
                  <div className="stats-grid" style={{ marginBottom: 24 }}>
                    <div className="stat-card">
                      <div className="stat-label">Average Score</div>
                      <div className="stat-num">{avg}</div>
                      <div className="stat-trend">pts Stableford</div>
                    </div>
                    <div className="stat-card">
                      <div className="stat-label">Best Score</div>
                      <div className="stat-num green">{best || '—'}</div>
                      <div className="stat-trend">↑ Personal best</div>
                    </div>
                    <div className="stat-card">
                      <div className="stat-label">Scores Logged</div>
                      <div className="stat-num">{scores.length}/5</div>
                      <div className="stat-trend">Rolling window</div>
                    </div>
                    <div className="stat-card">
                      <div className="stat-label">Trend</div>
                      <div className={`stat-num ${trend >= 0 ? 'green' : ''}`}>{trend >= 0 ? '+' : ''}{trend}</div>
                      <div className={`stat-trend ${trend < 0 ? 'down' : ''}`}>{trend >= 0 ? '↑ Improving' : '↓ Declining'}</div>
                    </div>
                  </div>

                  <div className="card" style={{ marginBottom: 24 }}>
                    <div className="section-eyebrow">Score History</div>
                    <div className="section-head">
                      <div className="section-title">Your Last 5 Scores</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Stableford Format · Range 1–45</div>
                    </div>
                    {scores.length > 0 ? (
                      <>
                        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, height: 120, marginBottom: 24 }}>
                          {scores.map(s => {
                            const isBest = s.value === best
                            return (
                              <div key={s.id} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                                <div style={{ fontSize: '0.75rem', color: isBest ? 'var(--gold)' : 'var(--cream)', fontFamily: 'Playfair Display, serif', fontWeight: 700 }}>{s.value}</div>
                                <div style={{ width: '100%', height: `${(s.value / 45) * 100}%`, background: isBest ? 'linear-gradient(180deg, var(--gold-light), var(--gold))' : 'linear-gradient(180deg, var(--green-bright), var(--green-mid))', borderRadius: '2px 2px 0 0', minHeight: 4 }} />
                                <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)', textAlign: 'center' }}>{new Date(s.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</div>
                              </div>
                            )
                          })}
                        </div>
                        {scores.map((s, i) => (
                          <div key={s.id} className="score-row">
                            <span className="score-rank">#{i + 1}</span>
                            <div className={`score-ball ${s.value === best ? 'best-score' : ''}`}>{s.value}</div>
                            <div className="score-info">
                              <div className="score-course">{new Date(s.date).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div>
                              <div className="score-date">{s.value} pts Stableford</div>
                            </div>
                            {s.value === best && <span className="score-badge">Best</span>}
                            <button className="score-delete" onClick={() => handleDeleteScore(s.id)} title="Remove score">✕</button>
                          </div>
                        ))}
                      </>
                    ) : (
                      <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text-muted)', fontSize: '0.9rem' }}>No scores yet. Add your first score below.</div>
                    )}
                  </div>

                  <div className="card">
                    <div className="section-eyebrow">Score Entry</div>
                    <div className="section-head">
                      <div className="section-title">Add New Score</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        {scores.length >= 5 ? 'Oldest score will be replaced (trigger handles this)' : `${5 - scores.length} slot${5 - scores.length !== 1 ? 's' : ''} available`}
                      </div>
                    </div>
                    <div className="add-score-form">
                      <div className="form-row">
                        <div className="field-grp">
                          <label className="field-lbl">Score (1–45)</label>
                          <input className="field-inp" type="number" min={1} max={45} placeholder="e.g. 38"
                            value={newScore} onChange={(e) => setNewScore(e.target.value)} />
                        </div>
                        <div className="field-grp">
                          <label className="field-lbl">Date Played</label>
                          <input className="field-inp" type="date" value={newDate} onChange={(e) => setNewDate(e.target.value)} />
                        </div>
                        <button className="btn-add" onClick={handleAddScore}>Add Score →</button>
                      </div>
                      {scoreMsg && <div className={`form-msg ${scoreMsg.startsWith('✓') ? 'success' : 'error'}`}>{scoreMsg}</div>}
                    </div>
                  </div>
                </>
              )}

              {/* ────────────────── DRAWS ────────────────── */}
              {activeTab === 'draws' && (
                <>
                  <div className="jackpot-banner" style={{ marginBottom: 24 }}>
                    <div>
                      <div className="jackpot-label">{nextDraw?.month || 'Upcoming'} · Jackpot Pool</div>
                      <div className="jackpot-amount">£5,000</div>
                      <div className="jackpot-sub">Draw end of {nextDraw?.month || '—'}</div>
                    </div>
                    <div>
                      <div className="jackpot-label" style={{ textAlign: 'right' }}>Your Scores (Draw Numbers)</div>
                      <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
                        {scores.length > 0 ? scores.map(s => (
                          <div key={s.id} style={{ width: 40, height: 40, borderRadius: '50%', background: 'rgba(29,74,46,0.3)', border: '1px solid rgba(61,186,110,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Playfair Display, serif', fontSize: '0.9rem', fontWeight: 900 }}>
                            {s.value}
                          </div>
                        )) : <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>No scores yet</div>}
                      </div>
                    </div>
                    <div className="jackpot-entries">
                      <div className="jackpot-label">Published Draws</div>
                      <div className="jackpot-entry-num">{winningsData.draws_entered}</div>
                      <div className="jackpot-sub" style={{ textAlign: 'right' }}>Total to date</div>
                    </div>
                  </div>

                  <div className="grid-2" style={{ marginBottom: 24 }}>
                    {[
                      { tier: '5 Number Match', pct: '40%', desc: 'Jackpot — rolls over if unclaimed', color: 'var(--gold)' },
                      { tier: '4 Number Match', pct: '35%', desc: 'Split equally among winners', color: 'var(--green-bright)' },
                    ].map(t => (
                      <div key={t.tier} className="card" style={{ padding: '20px 24px' }}>
                        <div className="card-label">{t.tier}</div>
                        <div className="card-value" style={{ color: t.color, fontSize: '1.8rem' }}>{t.pct} pool</div>
                        <div className="card-sub">{t.desc}</div>
                      </div>
                    ))}
                  </div>

                  <div className="card">
                    <div className="section-eyebrow">Draw History</div>
                    <div className="section-head"><div className="section-title">All Draws</div></div>
                    {draws.length > 0 ? draws.map(draw => {
                      const badge = getStatusBadge(draw.status)
                      const matchCount = draw.status.startsWith('matched') ? parseInt(draw.status.replace('matched', '')) : 0
                      return (
                        <div key={draw.id} className="draw-card">
                          <div className="draw-header">
                            <div className="draw-month">{draw.month}</div>
                            <div className="draw-status" style={{ background: badge.color, borderColor: badge.color, color: draw.status === 'pending' ? 'var(--gold)' : draw.status === 'no-match' ? 'var(--text-muted)' : 'var(--green-bright)' }}>
                              {badge.label}
                            </div>
                          </div>
                          <div className="draw-numbers">
                            {draw.numbers.map((n, j) => (
                              <div key={j} className={`draw-num ${matchCount > 0 && j < matchCount ? 'matched' : ''}`}>{n}</div>
                            ))}
                          </div>
                          {draw.prize && <div className="draw-prize">🏆 Prize won: {draw.prize}</div>}
                          {draw.status === 'pending' && <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>Draw result pending — end of {draw.month}</div>}
                        </div>
                      )
                    }) : (
                      <div style={{ textAlign: 'center', padding: '40px 0', color: 'var(--text-muted)', fontSize: '0.9rem' }}>No draws found.</div>
                    )}
                  </div>
                </>
              )}

              {/* ────────────────── CHARITY ────────────────── */}
              {activeTab === 'charity' && (
                <>
                  <div className="charity-card">
                    <div className="section-eyebrow">Currently Supporting</div>
                    <div className="charity-name">{userProfile?.charity_name || "St. Jude Children's Research Hospital"}</div>
                    <div className="charity-desc">
                      Your subscription contributes directly to life-changing charitable causes. Every month, a portion of your membership goes to the charity you support.
                    </div>
                    <div className="charity-pct-row">
                      <div>
                        <div className="pct-display">{charityPct}%</div>
                        <div className="pct-label">of subscription</div>
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginBottom: 8, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Adjust contribution (min 10%)</div>
                        <input className="pct-slider" type="range" min={10} max={50} value={charityPct}
                          onChange={(e) => handleCharityPctChange(parseInt(e.target.value))} style={{ width: '100%' }} />
                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.65rem', color: 'var(--text-muted)', marginTop: 4 }}>
                          <span>10%</span><span>50%</span>
                        </div>
                      </div>
                    </div>
                    <div className="charity-impact">
                      <div className="impact-tile">
                        <div className="impact-val">£{perMonthCharity}</div>
                        <div className="impact-lbl">Per month</div>
                      </div>
                      <div className="impact-tile">
                        <div className="impact-val">£{totalDonated.toFixed(2)}</div>
                        <div className="impact-lbl">Charity pool</div>
                      </div>
                      <div className="impact-tile">
                        <div className="impact-val">{monthsContributing} mo</div>
                        <div className="impact-lbl">Contributing</div>
                      </div>
                    </div>
                  </div>

                  <div className="card">
                    <div className="section-eyebrow">Charity Directory</div>
                    <div className="section-head"><div className="section-title">Change Charity</div></div>
                    <div className="charity-list">
                      {[
                        { icon: '🏥', name: "St. Jude Children's Hospital", sub: "Children's healthcare · USA" },
                        { icon: '🎗️', name: 'Cancer Research UK', sub: 'Cancer research · United Kingdom' },
                        { icon: '🧠', name: "Alzheimer's Society", sub: 'Dementia support · United Kingdom' },
                        { icon: '❤️', name: 'British Heart Foundation', sub: 'Heart disease · United Kingdom' },
                        { icon: '⛵', name: 'RNLI', sub: 'Sea rescue · United Kingdom & Ireland' },
                      ].map((c, i) => {
                        const isSelected = userProfile?.charity_name?.toLowerCase().includes(c.name.split("'")[0].trim().toLowerCase()) || (i === 0 && !userProfile?.charity_name)
                        return (
                          <button key={i} className={`charity-option ${isSelected ? 'selected' : ''}`}>
                            <div className="charity-opt-icon">{c.icon}</div>
                            <div style={{ flex: 1, textAlign: 'left' }}>
                              <div className="charity-opt-name">{c.name}</div>
                              <div className="charity-opt-sub">{c.sub}</div>
                            </div>
                            <div className="charity-opt-check">{isSelected && '✓'}</div>
                          </button>
                        )
                      })}
                    </div>
                  </div>
                </>
              )}

              {/* ────────────────── SUBSCRIPTION ────────────────── */}
              {activeTab === 'subscription' && (
                <>
                  <div className="plan-card">
                    <div className="plan-badge"><span className="plan-dot" />Active Subscription</div>
                    <div className="plan-name">{userProfile?.plan || 'Pro Monthly'}</div>
                    <div className="plan-price">
                      <span>{userProfile?.plan === 'Pro Yearly' ? '£47.88' : '£4.99'}</span> / {userProfile?.plan === 'Pro Yearly' ? 'year' : 'month'}
                    </div>
                    <div className="plan-features">
                      {['Full score tracking (5-score rolling window)', 'Monthly prize draw entry', 'Charity contribution (min 10%)', 'Performance analytics dashboard', 'Winner verification & payout', 'Unlimited score history export'].map((f, i) => (
                        <div key={i} className="plan-feat"><span className="plan-feat-dot" />{f}</div>
                      ))}
                    </div>
                    <div className="plan-actions">
                      <button className="btn-outline">Upgrade to Yearly — Save 20%</button>
                      <button className="btn-danger">Cancel Subscription</button>
                    </div>
                  </div>

                  <div className="renewal-info" style={{ marginBottom: 24 }}>
                    <div>
                      <div className="renewal-label">Next Renewal</div>
                      <div className="renewal-date">{formatDate(userProfile?.next_renewal || '')}</div>
                    </div>
                    <div>
                      <div className="renewal-label">Payment Method</div>
                      <div className="renewal-date">{userProfile?.payment_method || 'Card on file'}</div>
                    </div>
                    <div>
                      <div className="renewal-label">Member Since</div>
                      <div className="renewal-date">{formatMonthYear(userProfile?.member_since || '')}</div>
                    </div>
                    <div>
                      <div className="renewal-label">Status</div>
                      <div style={{ color: 'var(--green-bright)', fontWeight: 500, fontSize: '0.95rem', display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ width: 6, height: 6, background: 'var(--green-bright)', borderRadius: '50%', display: 'inline-block', animation: 'pulse 2s infinite' }} />
                        {userProfile?.subscription_status === 'active' ? 'Active' : userProfile?.subscription_status || 'Active'}
                      </div>
                    </div>
                  </div>

                  <div className="card" style={{ background: 'linear-gradient(135deg, rgba(29,74,46,0.2), rgba(29,74,46,0.05))', borderColor: 'rgba(61,186,110,0.2)' }}>
                    <div className="section-eyebrow">Special Offer</div>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 16 }}>
                      <div>
                        <div className="section-title" style={{ marginBottom: 6 }}>Switch to Yearly & Save £12</div>
                        <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', maxWidth: 400 }}>
                          Pay annually and get 2 months free. Your score tracking, prize draws, and charity contributions remain fully active.
                        </div>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 900, color: 'var(--green-bright)', lineHeight: 1 }}>£47.88</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 4 }}>per year · save £11.99</div>
                        <button className="btn-add" style={{ marginTop: 12, padding: '10px 24px' }}>Upgrade Now →</button>
                      </div>
                    </div>
                  </div>
                </>
              )}

              {/* ────────────────── WINNINGS ────────────────── */}
              {activeTab === 'winnings' && (
                <>
                  <div className="winnings-total">
                    <div>
                      <div className="win-total-label">Total Winnings</div>
                      <div className="win-total-val">£{winningsData.total.toFixed(2)}</div>
                    </div>
                    <div className="win-divider" />
                    <div>
                      <div className="win-stat-val">{winningsData.prizes_won}</div>
                      <div className="win-stat-lbl">{winningsData.prizes_won === 1 ? 'Prize won' : 'Prizes won'}</div>
                    </div>
                    <div className="win-divider" />
                    <div>
                      <div className="win-stat-val">{winningsData.draws_entered}</div>
                      <div className="win-stat-lbl">Draws entered</div>
                    </div>
                    <div className="win-divider" />
                    <div>
                      <div className="win-stat-val">{winningsData.win_rate}%</div>
                      <div className="win-stat-lbl">Win rate</div>
                    </div>
                  </div>

                  <div className="card" style={{ marginBottom: 24 }}>
                    <div className="section-eyebrow">Prize History</div>
                    <div className="section-head"><div className="section-title">Your Winnings</div></div>
                    {winningsData.prize_history.map((w, i) => (
                      <div key={i} className="win-row">
                        <div>
                          <div className="win-month">{w.month}</div>
                          <div className="win-match">{w.match}</div>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                          <div className="win-amount">{w.amount}</div>
                          <div className={`win-status ${w.status}`}>{w.status === 'paid' ? 'Paid' : 'Pending'}</div>
                        </div>
                      </div>
                    ))}
                    <div style={{ padding: '24px 0', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.85rem', borderTop: winningsData.prize_history.length > 0 ? '1px solid rgba(201,168,76,0.06)' : 'none' }}>
                      {winningsData.prize_history.length === 0
                        ? 'No winnings yet. Keep playing — the next draw is coming up!'
                        : `Keep playing — the next draw is ${nextDraw?.month || 'coming soon'}.`}
                    </div>
                  </div>

                  <div className="card" style={{ borderColor: 'rgba(201,168,76,0.2)' }}>
                    <div className="section-eyebrow">Winner Verification</div>
                    <div className="section-head"><div className="section-title">How Verification Works</div></div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                      {[
                        { num: '01', title: 'Win Notification', desc: 'You receive an email notification when your numbers match the draw.' },
                        { num: '02', title: 'Upload Proof', desc: 'Submit a screenshot of your scores from the golf platform.' },
                        { num: '03', title: 'Admin Review', desc: 'Our team reviews your submission within 48 hours.' },
                        { num: '04', title: 'Payment', desc: 'Once verified, payment is processed to your registered account.' },
                      ].map(s => (
                        <div key={s.num} style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
                          <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '2rem', fontWeight: 900, color: 'rgba(201,168,76,0.15)', lineHeight: 1, flexShrink: 0, width: 40 }}>{s.num}</div>
                          <div>
                            <div style={{ fontSize: '0.9rem', fontWeight: 500, color: 'var(--cream)', marginBottom: 4 }}>{s.title}</div>
                            <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', lineHeight: 1.6 }}>{s.desc}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}

              </>
            )}
          </div>
        </main>
      </div>
    </>
  )
}